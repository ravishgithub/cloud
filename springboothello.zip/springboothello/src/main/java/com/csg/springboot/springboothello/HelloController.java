package com.csg.springboot.springboothello;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class HelloController {

    @RequestMapping("/")
    public String index() {
        return "Greetings from Spring Boot!";
    }

    @RequestMapping("/hello")
    public String hello() {
        return "Hello from Spring Boot!";
    }
    
    @RequestMapping("/hellowc")
    public String helloWL() {
        return "Hello from Spring Boot!";
    }
}